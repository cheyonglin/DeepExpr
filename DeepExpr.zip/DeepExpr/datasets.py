import os
from pathlib import Path
from typing import List, Tuple
import cv2
import numpy as np
from PIL import Image
from torch.utils.data import Dataset
import torchvision.transforms as transforms

class MonkeyFaceDataset(Dataset):
    """
    从 images/ 和 labels/ 读取数据（YOLO txt）。每个 bbox 作为一个样本。
    返回 (face_tensor, class_id)
    """
    def __init__(self, images_dir: str, labels_dir: str, img_size: int = 224, transform=None):
        self.images_dir = Path(images_dir)
        self.labels_dir = Path(labels_dir)

        self.image_files = sorted([p for p in self.images_dir.iterdir() if p.suffix.lower() in ('.jpg','.png')])
        self.samples: List[Tuple[Path,int,Tuple[float,float,float,float]]] = []
        for img_path in self.image_files:
            label_path = self.labels_dir / (img_path.stem + ".txt")
            if not label_path.exists():
                continue
            with open(label_path, "r") as f:
                for line in f.readlines():
                    parts = line.strip().split()
                    if len(parts)<5:
                        continue
                    cls = int(float(parts[0]))
                    x, y, w, h = map(float, parts[1:5])
                    self.samples.append((img_path, cls, (x,y,w,h)))

        if transform is None:
            self.transform = transforms.Compose([
                transforms.Resize((img_size,img_size)),
                transforms.ToTensor(),
                transforms.Normalize([0.5,0.5,0.5],[0.5,0.5,0.5])
            ])
        else:
            self.transform = transform

        self.img_size = img_size

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        img_path, cls, bbox = self.samples[idx]
        img = cv2.imread(str(img_path))
        h, w = img.shape[:2]
        x, y, bw, bh = bbox
        cx, cy = x*w, y*h
        bw_pix, bh_pix = bw*w, bh*h
        x1, y1 = int(cx - bw_pix/2), int(cy - bh_pix/2)
        x2, y2 = int(cx + bw_pix/2), int(cy + bh_pix/2)

        x1, y1, x2, y2 = max(0,x1), max(0,y1), min(w,x2), min(h,y2)
        if x2<=x1 or y2<=y1:
            face = np.zeros((self.img_size,self.img_size,3),dtype=np.uint8)
        else:
            face = img[y1:y2, x1:x2]

        face = cv2.cvtColor(face, cv2.COLOR_BGR2RGB)
        face = Image.fromarray(face)
        face = self.transform(face)
        return face, cls
