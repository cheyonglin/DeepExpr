"""
train_monkey_expr_from_scratch.py

目录结构:
project/
  ├─ train_monkey_expr_from_scratch.py   # 本文件
  ├─ ir50.py
  ├─ mobilefacenet.py
  ├─ hyp_crossvit_affect.py
  ├─ model_file.py                       # 包含 pyramid_trans_expr
  ├─ dataset/
       ├─ images/
       │    ├─ train/
       │    ├─ val/
       │    ├─ test/
       ├─ labels/
            ├─ train/
            ├─ val/
            ├─ test/
"""

import os
import cv2
import time
import torch
import random
import numpy as np
from PIL import Image
from pathlib import Path
from typing import List, Tuple

import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms

# ------------------------
# IMPORT MODEL
# ------------------------
from model import pyramid_trans_expr

# ------------------------
# 权重初始化函数
# ------------------------
def init_weights(module):
    if isinstance(module, nn.Conv2d):
        nn.init.kaiming_normal_(module.weight, mode='fan_out', nonlinearity='relu')
        if module.bias is not None:
            nn.init.constant_(module.bias, 0)
    elif isinstance(module, nn.Linear):
        nn.init.xavier_normal_(module.weight)
        if module.bias is not None:
            nn.init.constant_(module.bias, 0)
    elif isinstance(module, (nn.BatchNorm2d, nn.BatchNorm1d, nn.GroupNorm)):
        nn.init.constant_(module.weight, 1)
        nn.init.constant_(module.bias, 0)

# ------------------------
# Dataset
# ------------------------
class MonkeyFaceDataset(Dataset):
    """YOLO label 数据，每个 bbox 是一个样本"""
    def __init__(self, images_dir: str, labels_dir: str, img_size: int = 224, transform=None, keep_out_of_bound=False):
        super().__init__()
        self.images_dir = Path(images_dir)
        self.labels_dir = Path(labels_dir)
        self.img_files = sorted([p for p in self.images_dir.iterdir() if p.suffix.lower() in ('.jpg','.png','.jpeg')])
        self.samples: List[Tuple[Path,int,Tuple[float,float,float,float]]] = []

        for img_path in self.img_files:
            label_path = self.labels_dir / (img_path.stem + '.txt')
            if not label_path.exists():
                continue
            with open(label_path, 'r') as f:
                lines = [ln.strip() for ln in f.readlines() if ln.strip()]
            for ln in lines:
                parts = ln.split()
                if len(parts) < 5:
                    continue
                cls = int(float(parts[0]))
                x, y, w, h = map(float, parts[1:5])
                self.samples.append((img_path, cls, (x,y,w,h)))

        if len(self.samples) == 0:
            raise RuntimeError(f"No samples found in {images_dir} with labels in {labels_dir}")

        self.img_size = img_size
        if transform is not None:
            self.transform = transform
        else:
            self.transform = transforms.Compose([
                transforms.Resize((img_size, img_size)),
                transforms.ToTensor(),
                transforms.Normalize([0.5,0.5,0.5],[0.5,0.5,0.5])
            ])
        self.keep_out_of_bound = keep_out_of_bound

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx: int):
        img_path, cls, bbox = self.samples[idx]
        img = cv2.imread(str(img_path))
        if img is None:
            raise RuntimeError(f"Failed to read image: {img_path}")
        h, w, _ = img.shape
        x, y, bw, bh = bbox
        cx = x*w; cy=y*h; bw_pix=bw*w; bh_pix=bh*h
        x1=int(round(cx-bw_pix/2)); y1=int(round(cy-bh_pix/2))
        x2=int(round(cx+bw_pix/2)); y2=int(round(cy+bh_pix/2))
        x1c, y1c, x2c, y2c = max(0,x1), max(0,y1), min(w,x2), min(h,y2)
        if x2c <= x1c or y2c <= y1c:
            if not self.keep_out_of_bound:
                face = np.zeros((self.img_size,self.img_size,3),dtype=np.uint8)
            else:
                face = img
        else:
            face = img[y1c:y2c,x1c:x2c]
        face = cv2.cvtColor(face, cv2.COLOR_BGR2RGB)
        face = Image.fromarray(face)
        face = self.transform(face)
        return face, cls

# ------------------------
# Training helpers
# ------------------------
def train_one_epoch(model, dataloader, criterion, optimizer, device):
    model.train()
    total_loss, correct, total = 0.0, 0, 0
    for imgs, labels in dataloader:
        imgs, labels = imgs.to(device), labels.to(device)
        optimizer.zero_grad()
        outputs, _ = model(imgs)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        total_loss += loss.item()*imgs.size(0)
        preds = outputs.argmax(dim=1)
        correct += (preds==labels).sum().item()
        total += imgs.size(0)
    return total_loss/total, correct/total

def evaluate(model, dataloader, criterion, device):
    model.eval()
    total_loss, correct, total = 0.0, 0, 0
    with torch.no_grad():
        for imgs, labels in dataloader:
            imgs, labels = imgs.to(device), labels.to(device)
            outputs, _ = model(imgs)
            loss = criterion(outputs, labels)
            total_loss += loss.item()*imgs.size(0)
            preds = outputs.argmax(dim=1)
            correct += (preds==labels).sum().item()
            total += imgs.size(0)
    return total_loss/total, correct/total

# ------------------------
# Main
# ------------------------
def main():
    # ---- Config ----
    data_root = "datasets"
    images_root, labels_root = os.path.join(data_root,"images"), os.path.join(data_root,"labels")
    train_images, train_labels = os.path.join(images_root,"train"), os.path.join(labels_root,"train")
    val_images, val_labels = os.path.join(images_root,"val"), os.path.join(labels_root,"val")
    test_images, test_labels = os.path.join(images_root,"test"), os.path.join(labels_root,"test")

    img_size, num_classes, batch_size, num_epochs = 224, 7, 32, 25
    lr, num_workers = 1e-4, 4
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    save_dir = "checkpoints"
    os.makedirs(save_dir, exist_ok=True)
    seed = 42; random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)

    # ---- Datasets ----
    train_transform = transforms.Compose([
        transforms.Resize((img_size,img_size)),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize([0.5]*3,[0.5]*3)
    ])
    val_transform = transforms.Compose([
        transforms.Resize((img_size,img_size)),
        transforms.ToTensor(),
        transforms.Normalize([0.5]*3,[0.5]*3)
    ])
    train_ds = MonkeyFaceDataset(train_images, train_labels, img_size, train_transform)
    val_ds = MonkeyFaceDataset(val_images, val_labels, img_size, val_transform)
    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True, num_workers=num_workers, pin_memory=True)
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False, num_workers=num_workers, pin_memory=True)

    print(f"Train samples: {len(train_ds)}, Val samples: {len(val_ds)}")

    # ---- Model ----
    model = pyramid_trans_expr(img_size=img_size, num_classes=num_classes, type="large")
    model.apply(init_weights)  # 从零训练
    model = model.to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=num_epochs)

    # ---- Training loop ----
    best_val_acc = 0.0
    for epoch in range(1, num_epochs+1):
        t0 = time.time()
        train_loss, train_acc = train_one_epoch(model, train_loader, criterion, optimizer, device)
        val_loss, val_acc = evaluate(model, val_loader, criterion, device)
        scheduler.step()
        print(f"[Epoch {epoch}/{num_epochs}] time:{time.time()-t0:.1f}s train_loss={train_loss:.4f} train_acc={train_acc:.4f} | val_loss={val_loss:.4f} val_acc={val_acc:.4f}")

        if val_acc>best_val_acc:
            best_val_acc=val_acc
            best_path = os.path.join(save_dir,f"best_epoch{epoch:03d}_acc{val_acc:.4f}.pth")
            torch.save({'epoch':epoch,'model_state_dict':model.state_dict(),'val_acc':val_acc}, best_path)
            print(f"Saved best model: {best_path}")

    # ---- Test ----
    if os.path.exists(test_images) and os.path.exists(test_labels):
        test_ds = MonkeyFaceDataset(test_images,test_labels,img_size,val_transform)
        test_loader = DataLoader(test_ds,batch_size=batch_size,shuffle=False,num_workers=num_workers)
        model.eval()
        preds_all=[]
        with torch.no_grad():
            for imgs,_ in test_loader:
                imgs = imgs.to(device)
                outputs,_ = model(imgs)
                preds_all.extend(outputs.argmax(dim=1).cpu().tolist())
        out_pred_file = os.path.join(save_dir,"test_preds.txt")
        with open(out_pred_file,'w') as f:
            for p in preds_all: f.write(f"{p}\n")
        print(f"Test preds saved to {out_pred_file}")

if __name__ == "__main__":
    main()
